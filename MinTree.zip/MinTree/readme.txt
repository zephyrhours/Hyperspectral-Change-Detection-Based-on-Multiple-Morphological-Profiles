
Input file path format:
yancheng_PCA_t1.jpg   

# Usage
Author: Zengfu Hou & Lu Li
All Rights Reserved !
Email: zephyrhou@126.com

Please input the file path：
yancheng_PCA_t1.jpg




# Citation

If these codes are helpful for you, please cite this paper:

@ARTICLE{9469924,
author={Hou, Zengfu and Li, Wei and Li, Lu and Tao, Ran and Du, Qian},
journal={IEEE Transactions on Geoscience and Remote Sensing},
title={Hyperspectral Change Detection Based on Multiple Morphological Profiles},
year={2021},
volume={},
number={},
pages={1-12},
doi={10.1109/TGRS.2021.3090802}}
